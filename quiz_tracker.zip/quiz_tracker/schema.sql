--DROP TABLE IF EXISTS students;

CREATE TABLE dim_students (
  student_id SERIAL PRIMARY KEY,
  firstname TEXT NOT NULL,
  lastname TEXT NOT NULL,
  email TEXT NOT NULL,
  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

DROP TABLE IF EXISTS quiz;

CREATE TABLE dim_quiz (
  quiz_id SERIAL PRIMARY KEY,
  subject TEXT NOT NULL,
  quiz_topic TEXT NOT NULL,
  questions INTEGER NOT NULL,
  quiz_date DATE NOT NULL,
  user_id INT NOT NULL,
  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE fact_grades (
  grade_id SERIAL PRIMARY KEY,
  student_id INTEGER NOT NULL,
  quiz_id INTEGER NOT NULL,
  right_answers INTEGER NULL,
  grade decimal(3,1) NOT NULL,
  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE fact_user_students 
(
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL,
  student_id INTEGER NOT NULL,
  user_role VARCHAR(255) NOT NULL, 
  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE log_in (
  user_id SERIAL PRIMARY KEY,
  firstname TEXT NOT NULL,
  lastname TEXT NOT NULL,
  email TEXT NOT NULL,
  password TEXT NOT NULL,
  last_login TIMESTAMP NULL,
  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
