# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 15:04:49 2020

@author: kbootsri
"""

from flask import (
    Blueprint, flash, g, redirect, render_template, request, url_for
)
from werkzeug.exceptions import abort

from quiz_tracker.auth import login_required
from quiz_tracker.db import (get_db, get_conn)

bp = Blueprint('quiz', __name__, url_prefix='/quiz')

    
@bp.route('/')
def index():
    db = get_db()
    db.execute('SELECT quiz_id, subject, quiz_topic, questions, quiz_date, user_id, created FROM "public"."dim_quiz" ORDER BY quiz_date DESC')
    quizzes = db.fetchall()
    return render_template('quiz/index.html', quizzes=quizzes)

@bp.route('/create', methods=('GET', 'POST'))
@login_required
def create():
    if request.method == 'POST':
        subject = request.form['subject']
        quiz_topic = request.form['quiz_topic']
        questions = request.form['questions'] 
        quiz_date = request.form['quiz_date']      
        error = None

        if not subject:
            error = 'Subject is required.'

        if not questions:
            error = 'Number of questions is required.'
            
        if not quiz_date:
            quiz_date = 'Exam date is required.'
            
        if error is not None:
            flash(error)
        else:
            connection = get_conn()
            cursor = connection.cursor()
            cursor.execute(
                'INSERT INTO "public"."dim_quiz" (subject, quiz_topic, questions, quiz_date, user_id) VALUES (%s, %s, %s, %s, %s)', (subject, quiz_topic, questions, quiz_date, g.user[0]))
            connection.commit()
            return redirect(url_for('quiz.index'))

    return render_template('quiz/create.html')

def get_quizid(id, check_author=True):
    db = get_db()
    quiz_id = db.execute('SELECT quiz_id, subject, quiz_topic, questions, quiz_date, user_id, created FROM "public"."dim_quiz" WHERE quiz_id = %s ORDER BY quiz_date DESC', (id,))
    
    quiz_id = db.fetchone()
    if quiz_id is None:
        abort(404, "Student id {0} doesn't exist.".format(id))

    if check_author and quiz_id[5] != g.user[0]:
        abort(403)

    return quiz_id

@bp.route('/<int:id>/update', methods=('GET', 'POST'))
@login_required
def update(id):
    post = get_quizid(id)

    if request.method == 'POST':
        subject = request.form['subject']
        quiz_topic = request.form['quiz_topic']
        questions = request.form['questions'] 
        quiz_date = request.form['quiz_date'] 
        error = None
        
        if not subject:
            error = 'Subject is required.'

        if not questions:
            error = 'Number of questions is required.'
            
        if not quiz_date:
            quiz_date = 'Exam date is required.'
            
        if error is not None:
            flash(error)
        else:
            connection = get_conn()
            cursor = connection.cursor()
            cursor.execute('UPDATE "public"."dim_quiz" SET subject = %s, quiz_topic = %s, questions = %s, quiz_date = %s WHERE quiz_id = %s', (subject, quiz_topic, questions, quiz_date, id))
            connection.commit()
            return redirect(url_for('quiz.index'))

    return render_template('students/update.html', post=post)


@bp.route('/<int:id>/delete', methods=('POST', 'GET'))
@login_required
def delete(id):
    get_quizid(id)
    connection = get_conn()
    cursor = connection.cursor()
    cursor.execute('DELETE FROM "public"."dim_quiz" WHERE quiz_id = %s', (id,))
    connection.commit()
    return redirect(url_for('quiz.index'))