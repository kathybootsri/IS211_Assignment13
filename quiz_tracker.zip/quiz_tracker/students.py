# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 15:04:49 2020

@author: kbootsri
"""

from flask import (
    Blueprint, flash, redirect, render_template, request, url_for
)
from werkzeug.exceptions import abort

from quiz_tracker.auth import login_required
from quiz_tracker.db import (get_db, get_conn)

bp = Blueprint('students', __name__, url_prefix='/students')


@bp.route('/students')
def index():
    db = get_db()
    db.execute('SELECT student_id, firstname, lastname, email, created FROM "public"."dim_students"')
    students = db.fetchall()
    
    if db.fetchall() is None:
        return redirect('/students/create')
    
    else:
        return render_template('students/index.html', students=students)

@bp.route('/create', methods=('GET', 'POST'))
@login_required
def create():
    if request.method == 'POST':
        firstname = request.form['firstname']
        lastname = request.form['lastname']
        email = request.form['email']        
        error = None

        if not firstname or not lastname:
            error = 'First and last name is required.'

        if not email:
            error = 'Email is required.'
            
        if error is not None:
            flash(error)
        else:
            connection = get_conn()
            cursor = connection.cursor()
            cursor.execute(
                'INSERT INTO "public"."dim_students" (firstname, lastname, email) VALUES (%s, %s, %s)', (firstname, lastname, email))
            connection.commit()
            return redirect(url_for('students.index'))

    return render_template('students/create.html')

def get_studentid(id, check_author=True):
    db = get_db()
    db.execute('SELECT s.student_id, s.firstname, s.lastname, s.email, s.created FROM "public"."dim_students" s WHERE s.student_id = %s', (id,))

    student_id = db.fetchone()

    if student_id is None:
        abort(404, "Student id {0} doesn't exist.".format(id))

#    if check_author and teacher_id != g.user[0]:
#        abort(403)

    return student_id

@bp.route('/<int:id>/update', methods=('GET', 'POST'))
@login_required
def update(id):
    post = get_studentid(id)

    if request.method == 'POST':
        firstname = request.form['firstname']
        lastname = request.form['lastname']
        email = request.form['email']        
        error = None
        
        if not firstname or not lastname:
            error = 'First and last name is required.'

        if not email:
            error = 'Email is required.'
            
        if error is not None:
            flash(error)
        else:
            connection = get_conn()
            cursor = connection.cursor()
            cursor.execute('UPDATE "public"."dim_students" SET firstname = %s, lastname = %s, email = %s WHERE student_id = %s', (firstname, firstname, email, id))
            connection.commit()
            return redirect(url_for('students.index'))

    return render_template('students/update.html', post=post)


@bp.route('/<int:id>/delete', methods=('POST','GET'))
@login_required
def delete(id):
    get_studentid(id)
    connection = get_conn()
    cursor = connection.cursor()
    cursor.execute('DELETE FROM "public"."dim_students" WHERE student_id = ?', (id,))
    connection.commit()
    return redirect(url_for('students.index'))