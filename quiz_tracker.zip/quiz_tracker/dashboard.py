# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 15:04:49 2020

@author: kbootsri
"""

from flask import (g, Blueprint, render_template, redirect, url_for)

from quiz_tracker.db import get_db

bp = Blueprint('dashboard', __name__)

@bp.route('/')
def index():
    if g.user is not None:
        db = get_db()
        db.execute('SELECT s.firstname, s.lastname, AVG(g.grade) as avg_grade FROM fact_grades g LEFT JOIN dim_students s on s.student_id = g.student_id GROUP BY 1, 2;')
        student_grades = db.fetchall()
        
        db.execute('SELECT q.subject, q.quiz_topic, AVG(g.grade), q.quiz_date as avg_grade FROM fact_grades g LEFT JOIN dim_quiz q on q.quiz_id=g.quiz_id GROUP BY 1, 2, 4;')
        quiz_grades = db.fetchall()
        return render_template('dashboard/index.html', student_grades=student_grades, quiz_grades=quiz_grades)
    
    else:
        return redirect(url_for('auth.login'))
