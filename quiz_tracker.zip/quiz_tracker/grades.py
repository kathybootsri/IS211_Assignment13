# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 15:04:49 2020

@author: kbootsri
"""

from flask import (
    Blueprint, flash, g, redirect, render_template, request, url_for
)
from werkzeug.exceptions import abort

from quiz_tracker.auth import login_required
from quiz_tracker.db import (get_db, get_conn)

bp = Blueprint('grades', __name__, url_prefix='/grades')

@bp.route('/')
def index():
    db = get_db()
    db.execute('SELECT g.*, s.firstname, s.lastname, q.subject, q.quiz_topic, q.questions, q.quiz_date FROM fact_grades g LEFT JOIN dim_students s on s.student_id=g.student_id LEFT JOIN dim_quiz q on q.quiz_id=g.quiz_id')
    posts = db.fetchall()
    return render_template('grades/index.html', posts=posts)

@bp.route('/create', methods=('GET', 'POST'))
@login_required
def create():
        
    db = get_db()
    db.execute('SELECT quiz_topic, quiz_id FROM "public"."dim_quiz" ORDER BY quiz_topic')
    topics = db.fetchall()

    db = get_db()
    db.execute('SELECT firstname, lastname, student_id AS name FROM "public"."dim_students" ORDER BY firstname')
    students = db.fetchall()        
        
    if request.method == 'POST':
        quiz_id = request.form['quiz_id']
        student_id = request.form['student_id']
        right_answers = request.form['right_answers']        
        grade = request.form['grade']      
        error = None

        if not quiz_id:
            error = 'Quiz topic is required.'

        if not student_id:
            error = 'Student first and last name is required.'
            
        if not right_answers and not grade:
            error = 'Either right answers or grade is required (not both).'            
            
        if error is not None:
            flash(error)
            
        else:            
            if right_answers:
                def get_questions(quiz_id):
                    db = get_db()
                    db.execute('SELECT * FROM dim_quiz WHERE quiz_id = %s', (quiz_id,))
                    grade_id = db.fetchone()
                    return grade_id[3]         
            
                calc_grade = float(right_answers)/get_questions(quiz_id)
                connection = get_conn()
                cursor = connection.cursor()                
                cursor.execute(
                    'INSERT INTO "public"."fact_grades" (student_id, quiz_id, right_answers, grade)'
                    ' VALUES (%s, %s, %s, %s)', (student_id, quiz_id, right_answers, calc_grade))
                connection.commit()
                return redirect(url_for('grades.index'))
            
            else: 
                connection = get_conn()
                cursor = connection.cursor()                   
                cursor.execute(
                    'INSERT INTO "public"."fact_grades" (student_id, quiz_id, grade)'
                    ' VALUES (%s, %s, %s)', (student_id, quiz_id, float(grade)*.01))
                connection.commit()
                return redirect(url_for('grades.index'))
            
    return render_template('grades/create.html', topics=topics, students=students)

def get_gradeid(id, check_author=True):
    db = get_db()
    db.execute('SELECT g.*, s.firstname, s.lastname, q.subject, q.quiz_topic, q.questions, q.quiz_date, q.user_id FROM "public"."fact_grades"  g LEFT JOIN dim_students s on s.student_id=g.student_id LEFT JOIN dim_quiz q on q.quiz_id=g.quiz_id WHERE g.grade_id = %s', (id,))
    
    grade_id = db.fetchone()
    
    if grade_id is None:
        abort(404, "Test grade id {0} doesn't exist.".format(id))

    if check_author and grade_id[12] != g.user[0]:
        abort(403)

    return grade_id

@bp.route('/<int:id>/update', methods=('GET', 'POST'))
@login_required
def update(id):
    post = get_gradeid(id)

    if request.method == 'POST':
        right_answers = request.form['right_answers']        
        grade = request.form['grade']      
        error = None
            
        if not right_answers and not grade:
            error = 'Either right answers or grade is required (not both).'      
            
        if error is not None:
            flash(error)
        else:
            if right_answers:
                connection = get_conn()
                cursor = connection.cursor()
                cursor.execute('UPDATE "public"."fact_grades" SET right_answers = %s WHERE grade_id = %s', (right_answers, id))
                connection.commit()
            else:
                connection = get_conn()
                cursor = connection.cursor()
                cursor.execute('UPDATE "public"."fact_grades" SET grade = %s WHERE grade_id = %s', (float(grade)*.01, id))
                connection.commit()
                
        return redirect(url_for('grades.index'))

    return render_template('grades/update.html', post=post)


@bp.route('/<int:id>/delete', methods=('POST','GET'))
@login_required
def delete(id):
    get_gradeid(id)
    connection = get_conn()
    cursor = connection.cursor()
    cursor.execute('DELETE FROM "public"."fact_grades" WHERE grade_id = %s', (id,))
    connection.commit()
    return redirect(url_for('grades.index'))